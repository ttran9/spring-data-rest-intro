package com.keysoft.bugtracker.service;

import com.keysoft.bugtracker.domain.Application;
import java.util.List;

public interface ApplicationService {
    List<Application> listApplications();

}


